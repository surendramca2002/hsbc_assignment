package com.hsbc.servcie;

import com.hsbc.model.PaySlip;

public interface PaySlipApiService {
	
	public PaySlip reteivePaySlip(Long empId);

}
