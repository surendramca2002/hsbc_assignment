package com.hsbc.model.db.repository;

import org.springframework.data.repository.CrudRepository;

import com.hsbc.model.db.State;

public interface StateRepository extends CrudRepository<State, Long>{

}
