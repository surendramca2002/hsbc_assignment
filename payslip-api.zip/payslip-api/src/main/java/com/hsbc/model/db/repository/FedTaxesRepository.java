package com.hsbc.model.db.repository;

import org.springframework.data.repository.CrudRepository;

import com.hsbc.model.db.FedTaxes;

public interface FedTaxesRepository extends CrudRepository<FedTaxes, Long>{
		
	} 
