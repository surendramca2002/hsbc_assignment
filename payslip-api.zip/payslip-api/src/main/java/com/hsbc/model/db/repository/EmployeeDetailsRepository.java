package com.hsbc.model.db.repository;

import org.springframework.data.repository.CrudRepository;

import com.hsbc.model.db.EmployeeDetails;

public interface EmployeeDetailsRepository extends CrudRepository<EmployeeDetails, Long>{
   
} 
