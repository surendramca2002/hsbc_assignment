insert into STATE values(1, 'California', 9.25);
insert into STATE values(2, 'Texas', 0.0);

insert into FED_TAXES values(1, 0.0, 20.0);

insert into EMPLOYEE_DETAILS values(101, 'Surendra',  4000.00, 1);
insert into EMPLOYEE_DETAILS values(102, 'Pankaj', 5000.00, 2);
insert into EMPLOYEE_DETAILS values(103, 'Kashyap', 6000.00, 1);